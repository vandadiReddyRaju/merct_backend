# Authentication & Authorization | Part 3

- Router Switch
  - User Defined Components
  - Redirect
- Wrapper Component
  - Protected Route
- Integrating APIs
  - Get All Products

