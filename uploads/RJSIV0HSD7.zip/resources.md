# Authentication & Authorization | Part 3

## API URL

```
https://apis.ccbp.in/products
```

## Add these below statements in your code to import React Loader Spinner

```js
import Loader from 'react-loader-spinner'
```

## Add this Component in your code to use React Loader Spinner

```js
<Loader type="TailSpin" color="#00BFFF" height={50} width={50} />
```

## Credentials

```
Username: rahul
password: rahul@2021
```

```
Username: praneetha
password: praneetha@2021
```
